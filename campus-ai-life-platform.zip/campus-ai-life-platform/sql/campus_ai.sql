-- Campus AI Life Platform / MySQL 8
-- 先导入 demo/mysql.sql，再执行本文件。

CREATE TABLE IF NOT EXISTS `ai_conversation` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '会话ID',
  `user_id` bigint NOT NULL COMMENT '学生用户ID',
  `title` varchar(100) NOT NULL COMMENT '会话标题',
  `created_time` datetime NOT NULL,
  `updated_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ai_conversation_user_updated` (`user_id`, `updated_time`),
  CONSTRAINT `fk_ai_conversation_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='AI会话';

CREATE TABLE IF NOT EXISTS `ai_message` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '消息ID',
  `conversation_id` bigint NOT NULL,
  `user_id` bigint NOT NULL COMMENT '冗余用户ID，便于审计与分区',
  `role` varchar(20) NOT NULL COMMENT 'user/assistant/system/tool',
  `content` mediumtext NOT NULL,
  `created_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ai_message_conversation_time` (`conversation_id`, `created_time`),
  KEY `idx_ai_message_user` (`user_id`),
  CONSTRAINT `fk_ai_message_conversation` FOREIGN KEY (`conversation_id`) REFERENCES `ai_conversation` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ai_message_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chk_ai_message_role` CHECK (`role` IN ('user','assistant','system','tool'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='AI长期消息记录';

-- PostgreSQL + pgvector（请在 PostgreSQL 数据库中单独执行）
-- CREATE EXTENSION IF NOT EXISTS vector;
-- vector_store 表可由 Spring AI 在 AI_RAG_ENABLED=true 时初始化。
