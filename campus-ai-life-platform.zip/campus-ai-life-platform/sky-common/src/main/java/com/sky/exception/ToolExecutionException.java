package com.sky.exception;

public class ToolExecutionException extends BaseException {
    public ToolExecutionException(String message) { super(message); }
}
