package com.sky.exception;

public class AgentExecutionException extends BaseException {
    public AgentExecutionException(String message) { super(message); }
}
