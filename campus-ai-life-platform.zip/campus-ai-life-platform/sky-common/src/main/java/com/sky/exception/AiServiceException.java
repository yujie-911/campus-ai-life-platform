package com.sky.exception;

/** AI 编排失败；继承既有异常基类以复用统一 Result。 */
public class AiServiceException extends BaseException {
    public AiServiceException(String message) { super(message); }
}
