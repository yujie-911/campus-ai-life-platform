package com.sky.exception;

public class RagException extends BaseException {
    public RagException(String message) { super(message); }
}
