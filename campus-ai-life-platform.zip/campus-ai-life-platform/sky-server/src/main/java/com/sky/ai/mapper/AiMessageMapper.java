package com.sky.ai.mapper;

import com.sky.entity.AiMessage;
import org.apache.ibatis.annotations.*;
import java.util.List;

@Mapper
public interface AiMessageMapper {
    @Insert("insert into ai_message(conversation_id,user_id,role,content,created_time) values(#{conversationId},#{userId},#{role},#{content},#{createdTime})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void insert(AiMessage message);

    @Select("select m.* from ai_message m join ai_conversation c on c.id=m.conversation_id where m.conversation_id=#{conversationId} and c.user_id=#{userId} order by m.created_time,m.id")
    List<AiMessage> listOwned(@Param("conversationId") Long conversationId, @Param("userId") Long userId);
}
