package com.sky.ai.tool;

import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import java.net.http.*;
import java.nio.file.*;
import java.time.Duration;

@Slf4j
public class ResourceDownloadTool {
    private static final int MAX_BYTES = 10 * 1024 * 1024;
    private final Path root;
    private final HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5))
            .followRedirects(HttpClient.Redirect.NEVER).build();
    public ResourceDownloadTool(Path outputRoot) { this.root = outputRoot.resolve("downloads"); }

    @Tool(description = "下载公开网络资源到受控目录，最大10MB，不跟随重定向")
    public String download(@ToolParam(description = "HTTP/HTTPS资源URL") String url,
                           @ToolParam(description = "安全文件名") String fileName) {
        try {
            var uri = SafeUrlValidator.validate(url);
            Path target = SafeFileSupport.resolve(root, fileName);
            HttpRequest request = HttpRequest.newBuilder(uri).timeout(Duration.ofSeconds(20)).GET().build();
            HttpResponse<byte[]> response = client.send(request, HttpResponse.BodyHandlers.ofByteArray());
            if (response.statusCode() / 100 != 2) return "下载失败，HTTP " + response.statusCode();
            if (response.body().length > MAX_BYTES) return "下载失败：文件超过10MB限制";
            Files.createDirectories(root);
            Files.write(target, response.body(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            log.info("AI工具 ResourceDownloadTool: host={}, file={}", uri.getHost(), target.getFileName());
            return "资源已保存：" + target;
        } catch (Exception e) {
            log.warn("资源下载失败", e);
            return "资源下载失败：" + e.getMessage();
        }
    }
}
