package com.sky.ai.tool;

import com.alibaba.fastjson.JSON;
import com.sky.entity.Orders;
import com.sky.service.OrderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import java.util.List;

@Slf4j
public class OrderQueryTool {
    private final OrderService orderService;
    private final Long authenticatedUserId;

    public OrderQueryTool(OrderService orderService, Long authenticatedUserId) {
        this.orderService = orderService;
        this.authenticatedUserId = authenticatedUserId;
    }

    @Tool(description = "查询当前登录学生自己的最近订单状态；不能查询其他用户")
    public String queryMyOrders(@ToolParam(description = "返回条数，1到10", required = false) Integer limit) {
        int safeLimit = limit == null ? 3 : Math.max(1, Math.min(limit, 10));
        log.info("AI工具 OrderQueryTool: authenticatedUserId={}, limit={}", authenticatedUserId, safeLimit);
        List<Orders> orders = orderService.queryLatestByUserId(authenticatedUserId, safeLimit);
        return JSON.toJSONString(orders.stream().map(o -> new OrderStatus(
                o.getId(), o.getNumber(), statusText(o.getStatus()), o.getAmount(), o.getOrderTime())).toList());
    }

    private String statusText(Integer status) {
        return switch (status == null ? 0 : status) {
            case 1 -> "待付款"; case 2 -> "待接单"; case 3 -> "制作/待配送";
            case 4 -> "配送中"; case 5 -> "已完成"; case 6 -> "已取消"; default -> "未知";
        };
    }
    private record OrderStatus(Long id, String number, String status, java.math.BigDecimal amount,
                               java.time.LocalDateTime orderTime) {}
}
