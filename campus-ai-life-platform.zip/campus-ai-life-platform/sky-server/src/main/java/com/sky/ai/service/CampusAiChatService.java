package com.sky.ai.service;

import com.sky.ai.agent.CampusLifeAgent;
import com.sky.ai.rag.CampusRagService;
import com.sky.ai.tool.CampusToolRegistry;
import com.sky.dto.AiChatRequest;
import com.sky.entity.*;
import com.sky.exception.AiServiceException;
import com.sky.vo.AiChatVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.client.advisor.vectorstore.QuestionAnswerAdvisor;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.chat.messages.*;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

@Slf4j
@Service
@RequiredArgsConstructor
public class CampusAiChatService {
    private static final String SYSTEM_PROMPT = """
            你是“校园智享 AI 助手”。你帮助学生处理校园生活问答、情感支持、真实餐食推荐、
            本人订单状态查询和校园活动计划。涉及菜品、价格、订单时必须调用业务工具，不能编造。
            不提供诊断；遇到自伤、暴力或紧急危险时优先建议联系当地紧急服务和学校专业人员。
            未经用户明确确认，不执行支付或不可逆操作。
            """;
    private final ObjectProvider<ChatModel> modelProvider;
    private final ObjectProvider<VectorStore> vectorStoreProvider;
    private final ChatMemory chatMemory;
    private final ConversationService conversationService;
    private final CampusToolRegistry toolRegistry;
    private final CampusLifeAgent agent;

    public AiChatVO chat(Long userId, AiChatRequest request) {
        AiConversation conversation = conversationService.getOrCreate(
                request.getConversationId(), userId, request.getMessage());
        hydrateMemory(conversation.getId(), userId);
        conversationService.saveMessage(conversation.getId(), userId, "user", request.getMessage());
        ChatModel model = modelProvider.getIfAvailable();
        if (model == null) {
            String fallback = "AI 模型尚未配置。请设置 AI_CHAT_MODEL=openai 和 AI_API_KEY；外卖业务可继续正常使用。";
            conversationService.saveMessage(conversation.getId(), userId, "assistant", fallback);
            return new AiChatVO(conversation.getId(), fallback, true);
        }
        try {
            String answer = request.isAgent() ? agent.run(userId, request.getMessage())
                    : client(model).prompt().user(request.getMessage())
                    .advisors(spec -> spec.param(ChatMemory.CONVERSATION_ID, conversationKey(conversation.getId(), userId)))
                    .toolCallbacks(toolRegistry.callbacks(userId)).call().content();
            conversationService.saveMessage(conversation.getId(), userId, "assistant", answer);
            return new AiChatVO(conversation.getId(), answer, false);
        } catch (Exception e) {
            log.error("AI对话失败 conversationId={}", conversation.getId(), e);
            throw new AiServiceException("AI 对话失败：" + e.getMessage());
        }
    }

    public SseEmitter stream(Long userId, Long conversationId, String message, boolean agentMode) {
        if (message == null || message.isBlank() || message.length() > 4000) throw new AiServiceException("消息长度应为1到4000");
        AiConversation conversation = conversationService.getOrCreate(conversationId, userId, message);
        hydrateMemory(conversation.getId(), userId);
        conversationService.saveMessage(conversation.getId(), userId, "user", message);
        SseEmitter emitter = new SseEmitter(180_000L);
        ChatModel model = modelProvider.getIfAvailable();
        if (model == null) {
            sendAndComplete(emitter, "error", "AI 模型未配置", conversation.getId());
            return emitter;
        }
        if (agentMode) {
            Thread.ofVirtual().start(() -> {
                try {
                    String answer = agent.run(userId, message);
                    emitter.send(SseEmitter.event().name("message").data(answer));
                    conversationService.saveMessage(conversation.getId(), userId, "assistant", answer);
                    emitter.send(SseEmitter.event().name("done").data(conversation.getId()));
                    emitter.complete();
                } catch (Exception e) { sendAndComplete(emitter, "error", e.getMessage(), conversation.getId()); }
            });
            return emitter;
        }
        StringBuilder full = new StringBuilder();
        AtomicBoolean ended = new AtomicBoolean();
        client(model).prompt().user(message)
                .advisors(spec -> spec.param(ChatMemory.CONVERSATION_ID, conversationKey(conversation.getId(), userId)))
                .toolCallbacks(toolRegistry.callbacks(userId)).stream().content()
                .subscribe(chunk -> {
                    if (ended.get()) return;
                    full.append(chunk);
                    try { emitter.send(SseEmitter.event().name("message").data(chunk)); }
                    catch (IOException e) { ended.set(true); emitter.completeWithError(e); }
                }, error -> {
                    ended.set(true);
                    sendAndComplete(emitter, "error", error.getMessage(), conversation.getId());
                }, () -> {
                    if (ended.compareAndSet(false, true)) {
                        conversationService.saveMessage(conversation.getId(), userId, "assistant", full.toString());
                        sendAndComplete(emitter, "done", "完成", conversation.getId());
                    }
                });
        emitter.onTimeout(() -> ended.set(true));
        emitter.onCompletion(() -> ended.set(true));
        return emitter;
    }

    private ChatClient client(ChatModel model) {
        ChatClient.Builder builder = ChatClient.builder(model).defaultSystem(SYSTEM_PROMPT)
                .defaultAdvisors(MessageChatMemoryAdvisor.builder(chatMemory).build());
        VectorStore vectorStore = vectorStoreProvider.getIfAvailable();
        if (vectorStore != null) builder.defaultAdvisors(new QuestionAnswerAdvisor(vectorStore));
        return builder.build();
    }

    private void hydrateMemory(Long conversationId, Long userId) {
        String key = conversationKey(conversationId, userId);
        chatMemory.clear(key);
        List<AiMessage> history = conversationService.messages(conversationId, userId);
        // MySQL 是长期事实源；每次请求重建有限窗口，重启后仍可继续对话。
        int from = Math.max(0, history.size() - 20);
        for (AiMessage saved : history.subList(from, history.size())) {
            Message message = "assistant".equals(saved.getRole())
                    ? new AssistantMessage(saved.getContent()) : new UserMessage(saved.getContent());
            chatMemory.add(key, message);
        }
    }

    private String conversationKey(Long conversationId, Long userId) { return userId + ":" + conversationId; }

    private void sendAndComplete(SseEmitter emitter, String event, String data, Long conversationId) {
        try {
            emitter.send(SseEmitter.event().name(event).data(data == null ? "未知错误" : data));
            emitter.send(SseEmitter.event().name("conversation").data(conversationId));
            emitter.complete();
        } catch (IOException e) { emitter.completeWithError(e); }
    }
}
