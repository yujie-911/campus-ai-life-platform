package com.sky.ai.agent;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sky.ai.config.CampusAiProperties;
import com.sky.ai.tool.CampusToolRegistry;
import com.sky.exception.AgentExecutionException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class CampusLifeAgent {
    private static final String SYSTEM = """
            你是校园智享 AI 助手，使用 ReAct：Reason -> Action -> Observation。
            每轮只输出严格 JSON：
            {"reason":"思考","action":"工具名或FINAL","arguments":{},"finalAnswer":"最终回答"}
            工具白名单：FoodSearchTool,DishRecommendTool,OrderQueryTool,WebSearchTool,
            WebScrapingTool,ResourceDownloadTool,PdfGenerationTool。
            不需要工具或已有足够观察时 action=FINAL。不得编造工具观察结果。
            """;
    private final ObjectProvider<ChatModel> modelProvider;
    private final CampusToolRegistry tools;
    private final CampusAiProperties properties;

    public String run(Long userId, String request) {
        ChatModel model = modelProvider.getIfAvailable();
        if (model == null) return "AI 模型未配置，无法执行复杂 Agent 任务";
        ChatClient client = ChatClient.builder(model).defaultSystem(SYSTEM).build();
        String context = "用户任务：" + request;
        int max = Math.max(1, Math.min(properties.getAgentMaxSteps(), 12));
        for (int step = 1; step <= max; step++) {
            try {
                String raw = client.prompt().user(context).call().content();
                JSONObject decision = parseJson(raw);
                String action = decision.getString("action");
                log.info("CampusLifeAgent step={}/{}, reason={}, action={}", step, max,
                        decision.getString("reason"), action);
                if ("FINAL".equalsIgnoreCase(action)) {
                    return decision.getString("finalAnswer");
                }
                String observation = executeWithRetry(action, decision.getJSONObject("arguments"), userId);
                context += "\n第" + step + "步 Reason：" + decision.getString("reason")
                        + "\nAction：" + action + "\nObservation：" + observation
                        + "\n请基于观察继续，完成时输出 FINAL。";
            } catch (Exception e) {
                log.error("CampusLifeAgent执行失败 step={}", step, e);
                throw new AgentExecutionException("Agent 第" + step + "步失败：" + e.getMessage());
            }
        }
        throw new AgentExecutionException("Agent 达到最大执行步数 " + max + "，已安全终止");
    }

    private String executeWithRetry(String action, JSONObject arguments, Long userId) {
        JSONObject safeArgs = arguments == null ? new JSONObject() : arguments;
        Exception last = null;
        for (int i = 0; i <= Math.max(0, properties.getAgentToolRetries()); i++) {
            try { return tools.execute(action, safeArgs, userId); }
            catch (Exception e) { last = e; log.warn("工具{}第{}次执行失败", action, i + 1, e); }
        }
        return "工具执行失败，已降级：" + (last == null ? "未知错误" : last.getMessage());
    }

    private JSONObject parseJson(String raw) {
        String text = raw == null ? "" : raw.strip();
        int start = text.indexOf('{'), end = text.lastIndexOf('}');
        if (start < 0 || end <= start) throw new AgentExecutionException("模型未返回合法 Agent JSON");
        return JSON.parseObject(text.substring(start, end + 1));
    }
}
