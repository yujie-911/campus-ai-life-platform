package com.sky.ai.tool;

import com.alibaba.fastjson.JSONObject;
import com.sky.ai.config.CampusAiProperties;
import com.sky.service.DishService;
import com.sky.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.ai.support.ToolCallbacks;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;
import java.nio.file.Path;

@Component
@RequiredArgsConstructor
public class CampusToolRegistry {
    private final DishService dishService;
    private final OrderService orderService;
    private final CampusAiProperties properties;

    public ToolCallback[] callbacks(Long authenticatedUserId) {
        Path root = Path.of(properties.getOutputDir());
        return ToolCallbacks.from(new FoodSearchTool(dishService), new DishRecommendTool(dishService),
                new OrderQueryTool(orderService, authenticatedUserId), new WebSearchTool(properties.getSearchApiKey()),
                new WebScrapingTool(), new ResourceDownloadTool(root), new PdfGenerationTool(root));
    }

    /** Agent 的显式 Action 分发器；工具名是固定白名单，不支持反射调用任意方法。 */
    public String execute(String tool, JSONObject a, Long userId) {
        Path root = Path.of(properties.getOutputDir());
        return switch (tool) {
            case "FoodSearchTool" -> new FoodSearchTool(dishService).searchFood(a.getString("name"),
                    a.getLong("categoryId"), a.getBigDecimal("maxPrice"), a.getString("taste"), a.getInteger("status"));
            case "DishRecommendTool" -> new DishRecommendTool(dishService).recommend(
                    a.getBigDecimal("budget"), a.getString("preference"));
            case "OrderQueryTool" -> new OrderQueryTool(orderService, userId).queryMyOrders(a.getInteger("limit"));
            case "WebSearchTool" -> new WebSearchTool(properties.getSearchApiKey()).searchWeb(a.getString("query"));
            case "WebScrapingTool" -> new WebScrapingTool().scrape(a.getString("url"));
            case "ResourceDownloadTool" -> new ResourceDownloadTool(root).download(a.getString("url"), a.getString("fileName"));
            case "PdfGenerationTool" -> new PdfGenerationTool(root).generate(a.getString("title"), a.getString("content"));
            default -> "拒绝未知工具：" + tool;
        };
    }
}
