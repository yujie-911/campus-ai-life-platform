package com.sky.ai.service;

import com.sky.ai.mapper.AiConversationMapper;
import com.sky.ai.mapper.AiMessageMapper;
import com.sky.entity.AiConversation;
import com.sky.entity.AiMessage;
import com.sky.exception.AiServiceException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ConversationService {
    private final AiConversationMapper conversationMapper;
    private final AiMessageMapper messageMapper;

    @Transactional
    public AiConversation getOrCreate(Long conversationId, Long userId, String firstMessage) {
        if (conversationId != null) {
            AiConversation owned = conversationMapper.findOwned(conversationId, userId);
            if (owned == null) throw new AiServiceException("会话不存在或无权访问");
            return owned;
        }
        LocalDateTime now = LocalDateTime.now();
        AiConversation created = new AiConversation();
        created.setUserId(userId);
        String normalized = firstMessage.strip().replaceAll("\\s+", " ");
        created.setTitle(normalized.substring(0, Math.min(30, normalized.length())));
        created.setCreatedTime(now);
        created.setUpdatedTime(now);
        conversationMapper.insert(created);
        return created;
    }

    @Transactional
    public void saveMessage(Long conversationId, Long userId, String role, String content) {
        // 所有权在写入前再次校验，防止通过伪造 conversationId 越权追加消息。
        if (conversationMapper.findOwned(conversationId, userId) == null) {
            throw new AiServiceException("会话不存在或无权访问");
        }
        AiMessage message = new AiMessage();
        message.setConversationId(conversationId);
        message.setUserId(userId);
        message.setRole(role);
        message.setContent(content);
        message.setCreatedTime(LocalDateTime.now());
        messageMapper.insert(message);
        conversationMapper.touch(conversationId, userId, LocalDateTime.now());
    }

    public List<AiConversation> list(Long userId) { return conversationMapper.listOwned(userId); }
    public List<AiMessage> messages(Long conversationId, Long userId) {
        if (conversationMapper.findOwned(conversationId, userId) == null) throw new AiServiceException("会话不存在或无权访问");
        return messageMapper.listOwned(conversationId, userId);
    }
}
