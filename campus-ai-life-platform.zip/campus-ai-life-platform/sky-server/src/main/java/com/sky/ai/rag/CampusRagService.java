package com.sky.ai.rag;

import com.sky.exception.RagException;
import lombok.RequiredArgsConstructor;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.*;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Service;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Service
@RequiredArgsConstructor
public class CampusRagService {
    private final ObjectProvider<VectorStore> vectorStoreProvider;

    public int initialize() {
        VectorStore store = vectorStoreProvider.getIfAvailable();
        if (store == null) throw new RagException("PGVector 未启用，请配置 Embedding 模型和 campus.ai.rag.enabled");
        try {
            List<Document> chunks = new ArrayList<>();
            var resources = new PathMatchingResourcePatternResolver().getResources("classpath*:knowledge/*.md");
            for (var resource : resources) {
                String text = resource.getContentAsString(StandardCharsets.UTF_8);
                for (int start = 0; start < text.length(); start += 800) {
                    int end = Math.min(text.length(), start + 1000);
                    chunks.add(new Document(text.substring(start, end),
                            Map.of("source", Objects.requireNonNullElse(resource.getFilename(), "unknown"))));
                    if (end == text.length()) break;
                }
            }
            if (!chunks.isEmpty()) store.add(chunks);
            return chunks.size();
        } catch (Exception e) {
            throw new RagException("知识库初始化失败：" + e.getMessage());
        }
    }

    public List<Document> search(String question) {
        VectorStore store = vectorStoreProvider.getIfAvailable();
        if (store == null) return List.of();
        return store.similaritySearch(SearchRequest.builder().query(question).topK(5).build());
    }
}
