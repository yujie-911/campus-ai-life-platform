package com.sky.ai.tool;

import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.pdmodel.*;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.*;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import java.nio.file.*;
import java.util.List;

@Slf4j
public class PdfGenerationTool {
    private final Path root;
    public PdfGenerationTool(Path outputRoot) { this.root = outputRoot.resolve("pdf"); }

    @Tool(description = "把校园活动或约会计划生成PDF；失败时返回友好错误而不终止应用")
    public String generate(@ToolParam(description = "PDF标题") String title,
                           @ToolParam(description = "PDF正文") String content) {
        if (title == null || title.isBlank() || content == null || content.isBlank()) return "标题和正文不能为空";
        String safeName = title.replaceAll("[^\\p{L}\\p{N}_-]", "_");
        if (safeName.isBlank()) safeName = "campus-plan";
        Path target = SafeFileSupport.resolve(root, safeName.substring(0, Math.min(60, safeName.length())) + ".pdf");
        try {
            Files.createDirectories(root);
            try (PDDocument document = new PDDocument()) {
                PDFont font = loadFont(document);
                PDPage page = new PDPage(PDRectangle.A4);
                document.addPage(page);
                PDPageContentStream stream = new PDPageContentStream(document, page);
                stream.beginText(); stream.setFont(font, 12); stream.setLeading(18); stream.newLineAtOffset(50, 790);
                for (String line : wrap(title + "\n\n" + content, 42)) {
                    if (line.equals("\f")) {
                        stream.endText(); stream.close();
                        page = new PDPage(PDRectangle.A4); document.addPage(page);
                        stream = new PDPageContentStream(document, page);
                        stream.beginText(); stream.setFont(font, 12); stream.setLeading(18); stream.newLineAtOffset(50, 790);
                    } else { stream.showText(line); stream.newLine(); }
                }
                stream.endText(); stream.close(); document.save(target.toFile());
            }
            log.info("AI工具 PdfGenerationTool: file={}", target);
            return "{\"fileName\":\"" + target.getFileName() + "\",\"filePath\":\"" + target.toString().replace("\\", "\\\\") + "\"}";
        } catch (Exception e) {
            log.warn("PDF生成失败", e);
            return "PDF生成失败：" + e.getMessage();
        }
    }

    private PDFont loadFont(PDDocument document) throws Exception {
        for (String candidate : List.of("C:/Windows/Fonts/simhei.ttf", "C:/Windows/Fonts/msyh.ttf",
                "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")) {
            Path path = Path.of(candidate);
            if (Files.isRegularFile(path)) return PDType0Font.load(document, path.toFile());
        }
        return new PDType1Font(Standard14Fonts.FontName.HELVETICA);
    }

    private List<String> wrap(String text, int width) {
        java.util.ArrayList<String> lines = new java.util.ArrayList<>();
        int onPage = 0;
        for (String paragraph : text.replace("\r", "").split("\n", -1)) {
            if (paragraph.isEmpty()) { lines.add(" "); onPage++; continue; }
            for (int i = 0; i < paragraph.length(); i += width) {
                if (onPage >= 40) { lines.add("\f"); onPage = 0; }
                lines.add(paragraph.substring(i, Math.min(paragraph.length(), i + width))); onPage++;
            }
        }
        return lines;
    }
}
