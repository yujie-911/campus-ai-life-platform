package com.sky.ai.tool;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

@Slf4j
public class WebSearchTool {
    private final String apiKey;
    private final HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    public WebSearchTool(String apiKey) { this.apiKey = apiKey == null ? "" : apiKey.strip(); }

    @Tool(description = "搜索公开网页；未配置 SEARCH_API_KEY 时返回配置提示")
    public String searchWeb(@ToolParam(description = "搜索关键词") String query) {
        if (apiKey.isBlank()) return "网页搜索未配置：请设置 SEARCH_API_KEY";
        if (query == null || query.isBlank() || query.length() > 200) return "搜索关键词长度应为1到200";
        try {
            String url = "https://www.searchapi.io/api/v1/search?engine=baidu&q="
                    + URLEncoder.encode(query, StandardCharsets.UTF_8) + "&api_key="
                    + URLEncoder.encode(apiKey, StandardCharsets.UTF_8);
            log.info("AI工具 WebSearchTool: query={}", query);
            HttpRequest request = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(10)).GET().build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() / 100 != 2) return "网页搜索暂时不可用，HTTP " + response.statusCode();
            JSONObject root = JSON.parseObject(response.body());
            JSONArray results = root.getJSONArray("organic_results");
            if (results == null) return "未找到相关网页";
            return results.subList(0, Math.min(5, results.size())).toString();
        } catch (Exception e) {
            log.warn("网页搜索失败", e);
            return "网页搜索暂时失败：" + e.getClass().getSimpleName();
        }
    }
}
