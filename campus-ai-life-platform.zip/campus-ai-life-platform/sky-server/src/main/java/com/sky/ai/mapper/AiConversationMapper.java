package com.sky.ai.mapper;

import com.sky.entity.AiConversation;
import org.apache.ibatis.annotations.*;
import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface AiConversationMapper {
    @Insert("insert into ai_conversation(user_id,title,created_time,updated_time) values(#{userId},#{title},#{createdTime},#{updatedTime})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void insert(AiConversation conversation);

    @Select("select * from ai_conversation where id=#{id} and user_id=#{userId}")
    AiConversation findOwned(@Param("id") Long id, @Param("userId") Long userId);

    @Select("select * from ai_conversation where user_id=#{userId} order by updated_time desc")
    List<AiConversation> listOwned(Long userId);

    @Update("update ai_conversation set updated_time=#{time} where id=#{id} and user_id=#{userId}")
    int touch(@Param("id") Long id, @Param("userId") Long userId, @Param("time") LocalDateTime time);
}
