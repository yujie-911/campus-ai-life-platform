package com.sky.ai.tool;

import com.alibaba.fastjson.JSON;
import com.sky.service.DishService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import java.math.BigDecimal;

@Slf4j
@RequiredArgsConstructor
public class DishRecommendTool {
    private final DishService dishService;

    @Tool(description = "根据总预算和口味返回真实在售菜品候选；只推荐，不会自动下单或支付")
    public String recommend(
            @ToolParam(description = "用户可接受的单份最高预算") BigDecimal budget,
            @ToolParam(description = "口味或需求关键词", required = false) String preference) {
        log.info("AI工具 DishRecommendTool: budget={}, preference={}", budget, preference);
        if (budget == null || budget.signum() <= 0 || budget.compareTo(new BigDecimal("10000")) > 0) {
            return "预算必须在0到10000元之间";
        }
        return JSON.toJSONString(dishService.searchForAi(null, null, budget, preference, 1, 8));
    }
}
