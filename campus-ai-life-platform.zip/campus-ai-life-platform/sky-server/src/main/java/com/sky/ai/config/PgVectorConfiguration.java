package com.sky.ai.config;

import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.ai.vectorstore.pgvector.PgVectorStore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import javax.sql.DataSource;

@Configuration
@ConditionalOnProperty(prefix = "campus.ai.rag", name = "enabled", havingValue = "true")
public class PgVectorConfiguration {
    @Bean("pgVectorDataSource")
    DataSource pgVectorDataSource(CampusAiProperties properties) {
        var rag = properties.getRag();
        DriverManagerDataSource ds = new DriverManagerDataSource();
        ds.setDriverClassName("org.postgresql.Driver");
        ds.setUrl(rag.getPostgresUrl());
        ds.setUsername(rag.getUsername());
        ds.setPassword(rag.getPassword());
        return ds;
    }

    @Bean("pgVectorJdbcTemplate")
    JdbcTemplate pgVectorJdbcTemplate(@Qualifier("pgVectorDataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean
    VectorStore campusVectorStore(@Qualifier("pgVectorJdbcTemplate") JdbcTemplate jdbcTemplate,
                                  EmbeddingModel embeddingModel, CampusAiProperties properties) {
        var rag = properties.getRag();
        return PgVectorStore.builder(jdbcTemplate, embeddingModel)
                .dimensions(rag.getDimensions())
                .distanceType(PgVectorStore.PgDistanceType.COSINE_DISTANCE)
                .indexType(PgVectorStore.PgIndexType.HNSW)
                .initializeSchema(rag.isInitializeSchema())
                .schemaName("public").vectorTableName("vector_store")
                .maxDocumentBatchSize(100).build();
    }
}
