package com.sky.ai.tool;

import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;

@Slf4j
public class WebScrapingTool {
    @Tool(description = "提取公开 HTTP/HTTPS 网页的可见文本，拒绝内网地址")
    public String scrape(@ToolParam(description = "网页URL") String url) {
        try {
            var uri = SafeUrlValidator.validate(url);
            log.info("AI工具 WebScrapingTool: host={}", uri.getHost());
            String text = Jsoup.connect(uri.toString()).timeout(10000).maxBodySize(2_000_000)
                    .userAgent("CampusAiLifeBot/1.0").get().text();
            return text.substring(0, Math.min(text.length(), 20_000));
        } catch (Exception e) {
            log.warn("网页抓取失败: {}", e.getMessage());
            return "网页抓取失败：" + e.getMessage();
        }
    }
}
