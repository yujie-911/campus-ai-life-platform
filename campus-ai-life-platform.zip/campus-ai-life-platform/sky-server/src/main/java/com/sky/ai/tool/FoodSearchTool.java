package com.sky.ai.tool;

import com.alibaba.fastjson.JSON;
import com.sky.service.DishService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import java.math.BigDecimal;

@Slf4j
@RequiredArgsConstructor
public class FoodSearchTool {
    private final DishService dishService;

    @Tool(description = "按菜名、分类、最高预算、口味和销售状态查询校园食堂真实菜品")
    public String searchFood(
            @ToolParam(description = "菜名关键字，可为空", required = false) String name,
            @ToolParam(description = "分类ID，可为空", required = false) Long categoryId,
            @ToolParam(description = "单份最高价格，可为空", required = false) BigDecimal maxPrice,
            @ToolParam(description = "口味关键字，例如辣、清淡，可为空", required = false) String taste,
            @ToolParam(description = "销售状态：1起售、0停售；推荐时应传1", required = false) Integer status) {
        log.info("AI工具 FoodSearchTool: name={}, categoryId={}, maxPrice={}, taste={}, status={}",
                name, categoryId, maxPrice, taste, status);
        if (status != null && status != 0 && status != 1) return "销售状态只能是0或1";
        return JSON.toJSONString(dishService.searchForAi(name, categoryId, maxPrice, taste, status, 10));
    }
}
