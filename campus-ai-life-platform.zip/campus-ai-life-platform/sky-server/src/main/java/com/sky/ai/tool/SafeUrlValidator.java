package com.sky.ai.tool;

import com.sky.exception.ToolExecutionException;
import java.net.*;

final class SafeUrlValidator {
    private SafeUrlValidator() {}

    static URI validate(String raw) {
        try {
            URI uri = URI.create(raw);
            if (!("http".equalsIgnoreCase(uri.getScheme()) || "https".equalsIgnoreCase(uri.getScheme()))
                    || uri.getHost() == null || uri.getUserInfo() != null) {
                throw new ToolExecutionException("仅允许不含用户信息的 HTTP/HTTPS 地址");
            }
            for (InetAddress address : InetAddress.getAllByName(uri.getHost())) {
                if (address.isAnyLocalAddress() || address.isLoopbackAddress() || address.isLinkLocalAddress()
                        || address.isSiteLocalAddress() || address.isMulticastAddress()) {
                    throw new ToolExecutionException("拒绝访问内网或本机地址");
                }
            }
            return uri;
        } catch (IllegalArgumentException | UnknownHostException e) {
            throw new ToolExecutionException("网址不合法或无法解析");
        }
    }
}
