package com.sky.ai.tool;

import com.sky.exception.ToolExecutionException;
import java.nio.file.Path;

final class SafeFileSupport {
    private SafeFileSupport() {}

    static Path resolve(Path root, String fileName) {
        if (fileName == null || fileName.isBlank() || fileName.length() > 120) {
            throw new ToolExecutionException("文件名不合法");
        }
        Path normalizedRoot = root.toAbsolutePath().normalize();
        Path target = normalizedRoot.resolve(fileName).normalize();
        if (!target.startsWith(normalizedRoot)) {
            throw new ToolExecutionException("拒绝目录穿越路径");
        }
        return target;
    }
}
