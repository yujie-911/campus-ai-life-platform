package com.sky.ai.config;

import org.springframework.ai.chat.memory.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CampusAiConfiguration {
    @Bean
    public ChatMemory campusChatMemory(CampusAiProperties properties) {
        // 短期窗口只负责控制 Prompt 大小；长期审计记录由 MySQL 保存，两者职责不同。
        return MessageWindowChatMemory.builder()
                .chatMemoryRepository(new InMemoryChatMemoryRepository())
                .maxMessages(properties.getMaxMemoryMessages()).build();
    }
}
