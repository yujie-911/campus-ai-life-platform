package com.sky.ai.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "campus.ai")
public class CampusAiProperties {
    private int maxMemoryMessages = 20;
    private int agentMaxSteps = 8;
    private int agentToolRetries = 1;
    private String outputDir = "./data/ai-output";
    private String searchApiKey = "";
    private Rag rag = new Rag();

    @Data
    public static class Rag {
        private boolean enabled;
        private String postgresUrl;
        private String username;
        private String password;
        private int dimensions = 1024;
        private boolean initializeSchema = true;
    }
}
