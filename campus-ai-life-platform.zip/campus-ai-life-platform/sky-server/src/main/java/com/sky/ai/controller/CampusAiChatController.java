package com.sky.ai.controller;

import com.sky.ai.rag.CampusRagService;
import com.sky.ai.service.*;
import com.sky.context.BaseContext;
import com.sky.dto.AiChatRequest;
import com.sky.entity.*;
import com.sky.result.Result;
import com.sky.vo.AiChatVO;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class CampusAiChatController {
    private final CampusAiChatService chatService;
    private final ConversationService conversationService;
    private final CampusRagService ragService;

    @PostMapping("/user/ai/chat")
    public Result<AiChatVO> chat(@Valid @RequestBody AiChatRequest request) {
        return Result.success(chatService.chat(BaseContext.getCurrentId(), request));
    }

    @GetMapping(value = "/user/ai/chat/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter stream(@RequestParam(required = false) Long conversationId,
                             @RequestParam String message,
                             @RequestParam(defaultValue = "false") boolean agent) {
        // 拦截器线程中立即捕获身份；异步 SSE/Tool 不依赖 ThreadLocal 跨线程传播。
        return chatService.stream(BaseContext.getCurrentId(), conversationId, message, agent);
    }

    @GetMapping("/user/ai/conversations")
    public Result<List<AiConversation>> conversations() {
        return Result.success(conversationService.list(BaseContext.getCurrentId()));
    }

    @GetMapping("/user/ai/conversations/{id}/messages")
    public Result<List<AiMessage>> messages(@PathVariable Long id) {
        return Result.success(conversationService.messages(id, BaseContext.getCurrentId()));
    }

    @PostMapping("/admin/ai/knowledge/init")
    public Result<Integer> initializeKnowledge() { return Result.success(ragService.initialize()); }
}
