package com.sky.ai.tool;

import com.sky.exception.ToolExecutionException;
import org.junit.jupiter.api.Test;
import java.nio.file.Path;
import static org.junit.jupiter.api.Assertions.*;

class SafeFileSupportTest {
    private final Path root = Path.of("build", "safe-files");

    @Test
    void resolvesAFileBelowTheConfiguredRoot() {
        Path result = SafeFileSupport.resolve(root, "report.pdf");
        assertTrue(result.startsWith(root.toAbsolutePath().normalize()));
        assertEquals("report.pdf", result.getFileName().toString());
    }

    @Test
    void rejectsDirectoryTraversalAndBlankNames() {
        assertThrows(ToolExecutionException.class,
                () -> SafeFileSupport.resolve(root, "../secret.txt"));
        assertThrows(ToolExecutionException.class,
                () -> SafeFileSupport.resolve(root, " "));
    }
}
