package com.sky.ai.tool;

import com.sky.exception.ToolExecutionException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SafeUrlValidatorTest {
    @Test
    void rejectsNonHttpSchemesAndCredentials() {
        assertThrows(ToolExecutionException.class, () -> SafeUrlValidator.validate("file:///etc/passwd"));
        assertThrows(ToolExecutionException.class, () -> SafeUrlValidator.validate("http://user:pass@example.com"));
    }

    @Test
    void rejectsLoopbackAndPrivateAddresses() {
        assertThrows(ToolExecutionException.class, () -> SafeUrlValidator.validate("http://127.0.0.1/admin"));
        assertThrows(ToolExecutionException.class, () -> SafeUrlValidator.validate("http://10.0.0.1/internal"));
    }
}
