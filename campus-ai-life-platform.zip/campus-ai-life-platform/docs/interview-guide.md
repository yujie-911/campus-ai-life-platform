# 校园智享生活平台面试指南

以下回答都对应当前工程。代码路径相对项目根目录；每题依次给出标准回答、项目实现、关键路径和可能追问。

## 1. 项目整体架构是什么？

**标准回答：** Maven 三模块单体，采用 MVC 分层；MySQL 存业务与长期会话，Redis 存高频状态，PGVector 存可重建向量索引。AI 编排通过 Service 工具接入业务。

**项目实现：** `sky-common` 提供横切能力，`sky-pojo` 提供数据模型，`sky-server` 承载餐饮域和 `com.sky.ai` 子域。**关键路径：** 根 `pom.xml`、`sky-server/src/main/java/com/sky/ai`。**追问：** 为什么不拆微服务？当前规模下单体事务和部署更简单，出现独立扩缩容或团队边界后再拆。

## 2. 用户下单完整流程是什么？

**标准回答：** JWT 识别用户，校验地址和购物车，读取商品事实，计算金额，事务写订单和明细并清购物车，再进入支付与状态流转。

**项目实现：** `OrderServiceImpl.submitOrder` 重新读取菜品/套餐，校验存在和启售，以数据库价格覆盖购物车快照并求和。**关键路径：** `controller/user/OrderController.java`、`service/impl/OrderServiceImpl.java`。**追问：** 如何处理并发改价？可加版本号、悲观锁或确认价有效期。

## 3. 为什么 Controller / Service / Mapper 分层？

**标准回答：** Controller 管协议与校验，Service 管业务规则、权限和事务，Mapper 管持久化，便于测试和复用。

**项目实现：** AI Tool 也调用 `DishService/OrderService`，自动复用业务边界。**关键路径：** `controller`、`service`、`mapper`、`ai/tool`。**追问：** 是否过度设计？跨表事务、权限与 AI 工具复用让 Service 层有实际价值。

## 4. 订单为什么使用事务？

**标准回答：** 主表、明细和购物车是一个原子动作，任一失败都应回滚。

**项目实现：** `submitOrder` 使用 `@Transactional`，金额重算和三组写操作位于同一事务。**关键路径：** `OrderServiceImpl.submitOrder`。**追问：** 支付能放在事务中吗？远程支付不应进入长事务，应使用回调幂等与补偿。

## 5. 事务可能在哪些情况下失效？

**标准回答：** 同类自调用、非 public、非 Spring Bean、异常被吞、回滚类型不匹配、跨线程或错误数据源。

**项目实现：** 注解位于 Spring Service 的 public 方法且异常外抛。**关键路径：** `OrderServiceImpl.java`。**追问：** SSE 异步能继承事务吗？不能，异步边界前应结束事务。

## 6. Redis 在项目中怎么使用？

**标准回答：** Redis 保存缓存和短期状态，MySQL 保存事实。

**项目实现：** `shop:status` 保存营业状态；AI 长期消息不放 Redis。**关键路径：** 两个 `ShopController.java`、`application.yml`。**追问：** 缓存一致性？复杂数据可采用更新数据库后删缓存、TTL 和延迟双删。

## 7. JWT 登录流程是什么？

**标准回答：** 登录成功签发含主体 ID 和有效期的 token；拦截器验签后把 ID 写入请求上下文，结束时清理。

**项目实现：** 管理端和用户端使用独立 secret、TTL、header，拦截器写入 `BaseContext`。**关键路径：** `JwtUtil.java`、`JwtTokenUserInterceptor.java`、`WebMvcConfiguration.java`。**追问：** 如何主动失效？可用 token version、Redis 黑名单或 access/refresh token。

## 8. AI 如何与传统业务融合？

**标准回答：** LLM 负责意图理解和表达，确定性业务由受控 Tool 调用现有 Service。

**项目实现：** 推荐读取真实在售菜品，订单问答读取本人订单。**关键路径：** `CampusAiChatService.java`、`CampusToolRegistry.java`。**追问：** 为什么不自动下单？写操作需二次确认、幂等键和审计后才能开放。

## 9. AI 为什么不能直接操作数据库？

**标准回答：** 模型输出不可信，开放 SQL 会造成越权、注入、误删和审计困难。

**项目实现：** 工具只暴露白名单字段，MyBatis 使用参数绑定，Tool 没有通用 JDBC 入口。**关键路径：** `FoodSearchTool.java`、`DishMapper.xml`。**追问：** 如何进一步隔离？只读账号、行级权限、审批型写工具与审计表。

## 10. Tool Calling 是什么？

**标准回答：** 模型按 schema 生成结构化调用，应用执行函数，再把结果交给模型组织答案。

**项目实现：** Spring AI 从 `@Tool` 对象生成 callback，注册表只开放固定白名单。**关键路径：** `ai/tool/*Tool.java`、`CampusToolRegistry.java`。**追问：** 工具结果可信么？外部内容仍要裁剪、过滤并视为不可信输入。

## 11. FoodSearchTool 完整调用链是什么？

**标准回答：** 自然语言 → 模型填参 → Tool 收窄参数 → Service 校验 → Mapper 参数查询 → 候选结果 → 模型解释。

**项目实现：** limit 封顶，金额/状态校验，`DishService.searchForAi` 调用 `DishMapper.searchForAi`。**关键路径：** `FoodSearchTool.java`、`DishServiceImpl.java`、`DishMapper.xml`。**追问：** “辣”怎么检索？当前匹配结构化口味/文本，后续可加标签或向量检索。

## 12. Chat Memory 怎么实现？

**标准回答：** 短期记忆按 conversationId 保留最近 N 条，控制上下文长度和费用。

**项目实现：** `MessageWindowChatMemory` 使用内存仓库，请求时从 MySQL 历史补水。**关键路径：** `CampusAiConfiguration.java`、`CampusAiChatService.java`。**追问：** 多实例怎么办？换 Redis/JDBC MemoryRepository，或每次按窗口读取长期库。

## 13. 对话为什么还需要数据库持久化？

**标准回答：** 内存重启会丢失，也不支持历史列表、审计和多实例共享。

**项目实现：** `ai_conversation`、`ai_message` 都记录 userId，归属查询强制带用户条件。**关键路径：** `ConversationService.java`、两个 AI Mapper、`sql/campus_ai.sql`。**追问：** 归档失败怎么办？生产可用 outbox 或补偿队列。

## 14. RAG 是什么？

**标准回答：** 先检索外部知识片段，再作为上下文生成答案，用于私域知识和及时更新。

**项目实现：** 校园 FAQ 进入 PGVector，Chat 附加 `QuestionAnswerAdvisor`。**关键路径：** `CampusRagService.java`、`PgVectorConfiguration.java`。**追问：** 能消除幻觉吗？不能，还需阈值、引用、拒答与评测。

## 15. 文档如何进入 PGVector？

**标准回答：** 加载、清洗、切分、添加 metadata、Embedding、写向量和正文。

**项目实现：** 管理员初始化接口读取 classpath Markdown，分块为 `Document` 后调用 `VectorStore.add`。**关键路径：** `POST /admin/ai/knowledge/init`、`CampusRagService.java`。**追问：** 如何去重？给文档/分块计算稳定 hash 并 upsert 或删除旧版本。

## 16. RAG 查询链路是什么？

**标准回答：** 问题 Embedding → topK 相似搜索 → 拼上下文 → LLM 基于上下文回答。

**项目实现：** `similaritySearch` 取少量文档，Advisor 注入提示词。**关键路径：** `CampusRagService.search`、`CampusAiChatService.java`。**追问：** topK 怎么调？用问答集衡量召回、忠实度、时延和 token 成本。

## 17. 为什么不用直接把全部文档放 Prompt？

**标准回答：** 窗口、费用和时延有限，无关文本还会稀释注意力并增加提示注入风险。

**项目实现：** PGVector 只召回相关分块，原始 Markdown 可重建。**关键路径：** `CampusRagService.java`。**追问：** 如何改进切分？标题感知、重叠窗口、父子块和 rerank。

## 18. Embedding 是什么？

**标准回答：** 将文本映射为固定维度向量，使语义相近文本距离更近。

**项目实现：** Spring AI `EmbeddingModel` 使用 OpenAI-compatible 配置，维度需与 PGVector 一致。**关键路径：** `application.yml`、`PgVectorConfiguration.java`。**追问：** 换模型为何重建？不同模型的向量空间通常不可比较。

## 19. ReAct 是什么？

**标准回答：** Reason + Act，模型交替推理、选择动作并观察结果，直到完成答案。

**项目实现：** JSON 表达 action/final，Observation 追加回上下文。**关键路径：** `CampusLifeAgent.java`。**追问：** 与一次 Tool Calling 区别？ReAct 支持多步依赖，但成本和失败面更大。

## 20. CampusLifeAgent 工作流程是什么？

**标准回答：** 接收目标、规划动作、白名单分派、记录观察、重试/继续、输出 final。

**项目实现：** 可组合餐饮、订单、网页、下载和 PDF 工具。**关键路径：** `CampusLifeAgent.java`、`CampusToolRegistry.java`。**追问：** JSON 不稳定怎么办？限制 schema、解析失败重试，或改用模型原生结构化输出。

## 21. 如何避免 Agent 无限调用工具？

**标准回答：** 最大步数、工具超时、重试上限、白名单、总预算和重复动作检测。

**项目实现：** 步数配置再封顶 12，重试有界，未知工具立即拒绝并记录日志。**关键路径：** `CampusAiProperties.java`、`CampusLifeAgent.java`。**追问：** 还能增加什么？wall-clock deadline、token/cost budget 与相同调用去重。

## 22. SSE 为什么适合 AI 输出？

**标准回答：** AI 是服务端单向持续输出；SSE 基于 HTTP、浏览器原生支持、比 WebSocket 更轻。

**项目实现：** `SseEmitter` 发送 conversation、message、done、error，异步前捕获认证 ID。**关键路径：** `CampusAiChatController.java`、`CampusAiChatService.java`。**追问：** 如何断线续传？事件 ID、持久化游标和 `Last-Event-ID`。

## 23. AI 查询订单怎么保证数据权限？

**标准回答：** 身份必须来自服务端认证上下文，不能信任模型参数，查询强制携带 userId。

**项目实现：** 工具创建时绑定当前用户，schema 不暴露 userId；Service 再校验并执行本人查询。**关键路径：** `CampusToolRegistry.java`、`OrderQueryTool.java`、`OrderServiceImpl.queryLatestByUserId`。**追问：** Controller 校验够吗？不够，Service/查询层也需约束。

## 24. PDF 工具如何实现？

**标准回答：** 校验标题、内容和文件名，在固定根目录输出，嵌入中文字体，异常转工具异常。

**项目实现：** PDFBox 分页生成；`SafeFileSupport` 防目录穿越，字体有回退。**关键路径：** `PdfGenerationTool.java`、`SafeFileSupport.java`。**追问：** 如何下载？生产返回鉴权资源 ID/短期签名 URL，而非服务器绝对路径。

## 25. 项目最有技术含量的三个点是什么？

**标准回答：** AI 与真实 Service 的安全融合；短期记忆、长期持久化、RAG 的三层上下文；订单一致性与 Agent 安全边界。

**项目实现：** Tool 无任意 SQL、订单身份服务端绑定；MySQL/ChatMemory/PGVector 各司其职；下单后端重算，Agent 有白名单、步数、重试、SSRF 和路径防护。**关键路径：** `ai/tool`、`ConversationService.java`、`CampusRagService.java`、`OrderServiceImpl.java`、`CampusLifeAgent.java`。**追问：** 下一步？Testcontainers 集成测试、AI 评测/可观测性、支付幂等和多商户模型。
