# 校园智享生活平台架构分析

## 1. 基线项目审计

### 1.1 sky-take-out

父工程 `com.sky:sky-take-out` 采用 Maven 聚合结构：

- `sky-common`：统一返回体、业务异常、JWT、线程上下文、配置属性与通用工具。
- `sky-pojo`：DTO、Entity、VO；覆盖用户、员工、分类、菜品、套餐、购物车、地址、订单和订单明细。
- `sky-server`：Spring MVC 接口、Service、MyBatis Mapper/XML、JWT 拦截器、Redis、WebSocket、定时任务和报表。

外卖核心调用链均为 `Controller -> Service -> Mapper -> MySQL`。学生侧位于 `controller/user`，管理侧位于 `controller/admin`。用户身份由 `JwtTokenUserInterceptor` 解析后写入 `BaseContext`。`OrderServiceImpl.submitOrder` 已使用事务完成订单、明细和购物车清理，但原实现直接接受 DTO 金额，需要改为按购物车关联的数据库菜品/套餐价格重新计算。订单查询 XML 已支持 `user_id` 条件，可作为 AI 权限查询的底层能力。

数据库基线包含 `user`、`employee`、`category`、`dish`、`dish_flavor`、`setmeal`、`setmeal_dish`、`shopping_cart`、`address_book`、`orders`、`order_detail`。原项目没有独立商家/食堂表，`employee + shop:* Redis 营业状态` 表达单商户模型；本次保持接口兼容，不强行改造成多租户。

### 1.2 yu-ai-agent

AI 项目基于 Java 21、Spring Boot 3.4.4、Spring AI 1.0：

- `LoveApp`：`ChatClient`、`MessageChatMemoryAdvisor`、流式输出、RAG Advisor、Tool Callback。
- `FileBasedChatMemory`：文件型记忆示例；适合借鉴 SPI，不直接迁移到生产。
- `rag`：Markdown 加载、Token 切分、查询重写、内存向量库与 PGVector 配置。
- `agent`：`BaseAgent -> ReActAgent -> ToolCallAgent -> YuManus`，带状态机和最大步数。
- `tools`：网页搜索、Jsoup 抓取、资源下载、PDF、文件、终止和终端工具。
- `AiController`：Flux 与 `SseEmitter` 两种 SSE 写法。
- `yu-image-search-mcp-server`：独立 MCP 示例，不并入主进程，只保留可选客户端配置。

可直接迁移的思想包括 ChatClient Builder、MessageWindowChatMemory、QuestionAnswerAdvisor、PGVector Builder、`@Tool` 注册、ReAct 步数控制和 SSE 事件模型。必须重写的部分包括恋爱大师提示词、业务工具、文件路径安全、SSRF 防护、API Key 缺省行为、用户鉴权、MySQL 会话持久化和异常体系。终端执行工具权限过大，不迁移。

## 2. 融合决策

采用 `sky-server` 内的 `com.sky.ai` 包，而不新增 Maven 模块。原因是 Food/Order Tool 必须复用既有 Service；放在独立模块会造成 `campus-ai -> sky-server` 与启动模块依赖关系复杂，且容易诱导工具绕过 Service。保持原三模块可最大程度降低外卖业务回归风险。

包结构：

```text
com.sky.ai
├── agent       # CampusLifeAgent、状态与执行结果
├── config      # 条件化 ChatModel、ChatClient、PGVector、工具注册
├── controller  # CampusAiChatController、知识库管理接口
├── memory      # Spring AI 短期窗口记忆
├── model       # 请求、响应、会话与消息模型
├── mapper      # ai_conversation / ai_message
├── rag         # 文档加载、切分、入库与检索
├── service     # 聊天编排、会话权限、降级实现
└── tool        # 业务工具及受限外部工具
```

## 3. 依赖与运行时边界

```text
HTTP/JWT
  -> CampusAiChatController
     -> CampusAiChatService
        -> ConversationService -> MyBatis -> MySQL
        -> ChatClient -> Model API
           -> ChatMemory (进程内短期窗口)
           -> QuestionAnswerAdvisor -> PGVector/PostgreSQL
           -> Tool callbacks -> 既有 DishService / OrderService

Redis：沿用店铺状态和缓存能力；不保存长期聊天正文。
```

Spring AI、Embedding、PGVector 和外部搜索均条件化创建。缺少模型 Key 或 PostgreSQL/Search API 配置时，外卖主应用仍能启动，AI 接口返回明确的“能力未配置”信息。

## 4. 数据库变化

MySQL 新增：

- `ai_conversation(id, user_id, title, created_time, updated_time)`，`(user_id, updated_time)` 索引。
- `ai_message(id, conversation_id, user_id, role, content, created_time)`，会话外键及时间索引。

PostgreSQL 只承载 Spring AI `vector_store`，启用 `vector` 扩展，文档正文、metadata、embedding 由 Spring AI 管理。MySQL 是业务与审计事实源，PGVector 是可重建的检索索引。

## 5. AI 调用业务系统方式

- `FoodSearchTool`、`DishRecommendTool` 仅接收预算、名称、分类、口味、状态等白名单参数，并调用 `DishService.searchForAi`。
- `OrderQueryTool` 不暴露 `userId` 参数；工具注册时由服务端绑定当前 JWT 用户，仅调用 `OrderService.queryLatestByUserId`。
- 工具绝不接收 SQL，也不持有通用 JDBC/Mapper 执行入口。
- 下单仍只能走原订单接口和事务 Service；AI 当前提供查询、推荐和计划，不静默替用户支付或下单。

## 6. 预计新增与修改

新增类：`CampusAiChatController`、`CampusAiChatService`、`ConversationService`、`AiConversationMapper`、`AiMessageMapper`、`CampusAiProperties`、`CampusAiConfiguration`、`CampusRagService`、`CampusKnowledgeLoader`、`FoodSearchTool`、`DishRecommendTool`、`OrderQueryTool`、`WebSearchTool`、`WebScrapingTool`、`ResourceDownloadTool`、`PdfGenerationTool`、`CampusLifeAgent`，以及 AI DTO/Entity/VO 和四类异常。

修改类：父/服务端 POM（Java 21、Spring Boot 3.4.4、Spring AI 依赖）、`DishService`/实现（受控检索）、`OrderService`/实现（本人订单查询与后端重算金额）、`WebMvcConfiguration`（AI 接口仍由用户 JWT 保护）、`GlobalExceptionHandler`（AI 异常映射）、应用配置与 README。

## 7. 分阶段验收

每个阶段执行 Maven 编译；最终增加不依赖真实模型的单元测试，覆盖参数校验、路径约束、URL 安全和用户权限入口。外部数据库/Redis/模型的集成测试通过独立 profile 执行，避免开发机缺少服务时阻断构建。
