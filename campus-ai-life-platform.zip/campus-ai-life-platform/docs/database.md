# 数据库设计

平台采用按职责拆分的三类存储。

## MySQL：业务事实与对话审计

原 `demo/mysql.sql` 保存用户、菜品、套餐、购物车、地址、订单及明细。新增的 `sql/campus_ai.sql` 创建 `ai_conversation` 与 `ai_message`。会话和消息都记录 `user_id`；Mapper 查询必须同时携带会话 ID 与当前 JWT 用户 ID，因此猜到其他会话 ID 也不能读取。

订单提交在同一个 Spring 事务内重新读取菜品/套餐价格，创建订单与明细并清空购物车。MySQL 是金额、状态和长期对话的唯一事实源。

## Redis：高频状态与缓存

沿用外卖项目的 `shop:status` 营业状态，并可扩展热点菜品、验证码和限流计数。Redis 不承担聊天正文的永久存储；缓存丢失不能破坏业务事实。

## PostgreSQL + PGVector：可重建的向量索引

1. 创建数据库 `campus_ai`，执行 `CREATE EXTENSION IF NOT EXISTS vector;`。
2. 配置 `PGVECTOR_URL/USERNAME/PASSWORD`、Embedding 模型和维度。
3. 设置 `AI_RAG_ENABLED=true` 后启动。
4. 管理员调用 `POST /admin/ai/knowledge/init`，系统读取 `resources/knowledge/*.md`、切分、Embedding 并写入 `vector_store`。

向量库内容可以从原始 Markdown 重建，不与 MySQL 做分布式事务。模型维度必须与 `PGVECTOR_DIMENSIONS` 一致；DashScope `text-embedding-v3` 常按实际服务配置选择维度。
