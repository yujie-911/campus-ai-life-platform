package com.sky.entity;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class AiConversation {
    private Long id;
    private Long userId;
    private String title;
    private LocalDateTime createdTime;
    private LocalDateTime updatedTime;
}
