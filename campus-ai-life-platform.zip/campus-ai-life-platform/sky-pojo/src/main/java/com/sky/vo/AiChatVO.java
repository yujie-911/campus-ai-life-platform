package com.sky.vo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AiChatVO {
    private Long conversationId;
    private String content;
    private boolean degraded;
}
