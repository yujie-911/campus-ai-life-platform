package com.sky.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class AiChatRequest {
    private Long conversationId;
    @NotBlank(message = "消息不能为空")
    @Size(max = 4000, message = "消息不能超过4000字")
    private String message;
    /** agent=true 时进入有最大步数限制的复杂任务模式。 */
    private boolean agent;
}
